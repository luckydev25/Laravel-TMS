
<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="row1" data-id="<?php echo e($task->id); ?>">
        <td><?php echo e($task->id); ?></td>
        <td><?php echo e(Carbon\Carbon::parse($task->created_at)->format('m-d-Y')); ?></td>
        <td><?php echo e($task->task_title); ?> </td>

        <td>
            <?php if(Auth::user()->admin): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <?php if( $user->id == $task->user_id ): ?>
                        <a href="<?php echo e(route('user.list', [ 'id' => $user->id ])); ?>"><?php echo e($user->name); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <span class="label label-jc"><?php echo e($task->project->project_name); ?></span>
            <?php else: ?>
                <a href="<?php echo e(route('user.list', [ 'id' => Auth::user()->id ])); ?>"><?php echo e(Auth::user()->name); ?></a>
                <span class="label label-jc"><?php echo e($task->project->project_name); ?></span>
            <?php endif; ?>
        </td>

        <td>
            <?php if( $task->priority == 0 ): ?>
                <span class="label label-info">Normal</span>
            <?php else: ?>
                <span class="label label-danger">High</span>
            <?php endif; ?>
        </td>
        <td>
            <?php if( !$task->completed ): ?>
                <a href="<?php echo e(route('task.completed', ['id' => $task->id])); ?>" class="btn btn-warning"> Mark as completed</a>
                <span class="label label-danger"><?php echo e(( $task->duedate < Carbon\Carbon::now() )  ? "!" : ""); ?></span>
            <?php else: ?>
                <span class="label label-success">Completed</span>
            <?php endif; ?>
        </td>
        <td>
            <a href="<?php echo e(route('task.view', ['id' => $task->id])); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
            <?php if(Auth::user()->admin): ?>
            <a href="<?php echo e(route('task.delete', ['id' => $task->id])); ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
            <?php endif; ?>
        </td>
    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>